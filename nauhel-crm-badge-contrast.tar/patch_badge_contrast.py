#!/usr/bin/env python3
"""
Prida getBadgeTextColor(hex) do constants.js - podle WCAG kontrastu spocita,
jestli ma byt text na barevnem pozadi bily nebo tmavy - a pouzije to
na obou mistech, kde se STATUS_COLORS pouziva jako pozadi badge (Seznam
view na Prehledu + status badge na detailu dealu).

Bezpecne: kazda nahrada se overuje na presny pocet vyskytu PRED zapisem,
zaloha vsech puvodnich souboru vedle nich (.bak).
"""
import sys

CONSTANTS_PATH = "frontend-admin/lib/constants.js"
LIST_PATH = "frontend-admin/app/page.js"
DETAIL_PATH = "frontend-admin/app/deals/[id]/page.js"

CONSTANTS_OLD = '''export const STATUS_COLORS = {
  Lead: "#9ca3af",
  "Kvalifikovaný lead": "#64748b",
  Nabídka: "#e0b478",
  Objednávka: "#b5652d",
  "Zálohová faktura": "#7a3a1a",
  Vyrobeno: "#2f6f4f",
  Fakturováno: "#1f5c3a",
  Ztraceno: "#a33b3b",
};'''

CONSTANTS_NEW = '''export const STATUS_COLORS = {
  Lead: "#9ca3af",
  "Kvalifikovaný lead": "#64748b",
  Nabídka: "#e0b478",
  Objednávka: "#b5652d",
  "Zálohová faktura": "#7a3a1a",
  Vyrobeno: "#2f6f4f",
  Fakturováno: "#1f5c3a",
  Ztraceno: "#a33b3b",
};

// Podle WCAG kontrastu spocita, jestli ma byt text na dane barve pozadi
// bily nebo tmavy - resi spatnou citelnost bileho textu na svetlejsich
// odstinech (napr. Nabidka #e0b478).
export function getBadgeTextColor(hex) {
  const c = hex.replace("#", "");
  const r = parseInt(c.substring(0, 2), 16) / 255;
  const g = parseInt(c.substring(2, 4), 16) / 255;
  const b = parseInt(c.substring(4, 6), 16) / 255;
  const toLinear = (v) => (v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4));
  const luminance = 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
  const contrastWithWhite = 1.05 / (luminance + 0.05);
  return contrastWithWhite >= 4.5 ? "#fff" : "var(--ink-900)";
}'''

LIST_OLD = '''                        <span className="badge" style={{ background: STATUS_COLORS[deal.status] }}>
                          {deal.status}
                        </span>'''

LIST_NEW = '''                        <span
                          className="badge"
                          style={{
                            background: STATUS_COLORS[deal.status],
                            color: getBadgeTextColor(STATUS_COLORS[deal.status]),
                          }}
                        >
                          {deal.status}
                        </span>'''

DETAIL_OLD = '''          <span className="badge" style={{ background: STATUS_COLORS[deal.status], fontSize: 13 }}>
            {deal.status}
          </span>'''

DETAIL_NEW = '''          <span
            className="badge"
            style={{
              background: STATUS_COLORS[deal.status],
              color: getBadgeTextColor(STATUS_COLORS[deal.status]),
              fontSize: 13,
            }}
          >
            {deal.status}
          </span>'''

LIST_IMPORT_OLD = 'import { DEAL_STATUSES, STATUS_COLORS } from "@/lib/constants";'
LIST_IMPORT_NEW = 'import { DEAL_STATUSES, STATUS_COLORS, getBadgeTextColor } from "@/lib/constants";'

DETAIL_IMPORT_OLD = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS } from "@/lib/constants";'
DETAIL_IMPORT_NEW = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS, getBadgeTextColor } from "@/lib/constants";'


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    for p in (CONSTANTS_PATH, LIST_PATH, DETAIL_PATH):
        backup(p)

    apply_patch(CONSTANTS_PATH, CONSTANTS_OLD, CONSTANTS_NEW, "pridani getBadgeTextColor")
    apply_patch(LIST_PATH, LIST_IMPORT_OLD, LIST_IMPORT_NEW, "import v Seznam view")
    apply_patch(LIST_PATH, LIST_OLD, LIST_NEW, "badge barva textu v Seznam view")
    apply_patch(DETAIL_PATH, DETAIL_IMPORT_OLD, DETAIL_IMPORT_NEW, "import v detailu dealu")
    apply_patch(DETAIL_PATH, DETAIL_OLD, DETAIL_NEW, "badge barva textu v detailu dealu")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "getBadgeTextColor" "{CONSTANTS_PATH}" "{LIST_PATH}" "{DETAIL_PATH}"')
