#!/usr/bin/env python3
"""
Prazdne stavy na detailu dealu (Dokumenty/Poznamky/Prilohy - "Zatim zadne...")
dostanou stejny vizualni vzor jako prazdny sloupec na Kanbanu (dashed box)
plus malou ikonku podle typu obsahu. Cistokosmeticka uprava, zadna nova logika.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/app/deals/[id]/page.js"

EMPTY_BOX_STYLE = '''{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 6,
                border: "1px dashed var(--paper-200)",
                borderRadius: 10,
                padding: "20px 12px",
                textAlign: "center",
              }'''

DOCS_OLD = '''          <div style={{ fontSize: 13.5, color: "var(--ink-400)" }}>Zatím žádné dokumenty</div>'''
DOCS_NEW = '''          <div style=''' + EMPTY_BOX_STYLE + '''>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-400)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 3v4a1 1 0 0 0 1 1h4" />
              <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
            </svg>
            <div style={{ fontSize: 13.5, color: "var(--ink-400)" }}>Zatím žádné dokumenty</div>
          </div>'''

NOTES_OLD = '''          <div style={{ fontSize: 13, color: "var(--ink-400)" }}>Zatím žádné poznámky</div>'''
NOTES_NEW = '''          <div style=''' + EMPTY_BOX_STYLE + '''>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-400)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
              <path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
            <div style={{ fontSize: 13, color: "var(--ink-400)" }}>Zatím žádné poznámky</div>
          </div>'''

ATTACH_OLD = '''            <div style={{ fontSize: 13, color: "var(--ink-400)" }}>Zatím žádné přílohy</div>'''
ATTACH_NEW = '''            <div style=''' + EMPTY_BOX_STYLE + '''>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-400)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21.44 11.05l-9.19 9.19a5 5 0 0 1-7.07-7.07l9.19-9.19a3.5 3.5 0 0 1 4.95 4.95l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
              </svg>
              <div style={{ fontSize: 13, color: "var(--ink-400)" }}>Zatím žádné přílohy</div>
            </div>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(JS_PATH)
    apply_patch(JS_PATH, DOCS_OLD, DOCS_NEW, "prazdny stav Dokumenty")
    apply_patch(JS_PATH, NOTES_OLD, NOTES_NEW, "prazdny stav Poznamky")
    apply_patch(JS_PATH, ATTACH_OLD, ATTACH_NEW, "prazdny stav Prilohy")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "dashed var(--paper-200)" "{JS_PATH}"')
