"use client";

import { useEffect, useState, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";
import { isLoggedIn, clearToken, api } from "@/lib/api";

function formatNotifDate(iso) {
  const utcIso = iso.endsWith("Z") || iso.includes("+") ? iso : iso + "Z";
  return new Date(utcIso).toLocaleString("cs-CZ");
}

export default function ProtectedShell({ children }) {
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState(null);

  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [showPanel, setShowPanel] = useState(false);
  const panelRef = useRef(null);

  useEffect(() => {
    if (!isLoggedIn()) {
      router.replace("/login");
      return;
    }
    api
      .get("/auth/me")
      .then((data) => {
        setUser(data);
        setReady(true);
      })
      .catch(() => {
        router.replace("/login");
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!ready) return;
    function pollUnread() {
      api
        .get("/notifications/unread-count")
        .then((data) => setUnreadCount(data.unread_count))
        .catch(() => {});
    }
    pollUnread();
    const interval = setInterval(pollUnread, 30000);
    return () => clearInterval(interval);
  }, [ready]);

  useEffect(() => {
    function handleClickOutside(e) {
      if (panelRef.current && !panelRef.current.contains(e.target)) {
        setShowPanel(false);
      }
    }
    if (showPanel) {
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [showPanel]);

  function togglePanel() {
    if (!showPanel) {
      api
        .get("/notifications")
        .then(setNotifications)
        .catch(() => {});
    }
    setShowPanel(!showPanel);
  }

  async function handleMarkAllRead() {
    try {
      await api.post("/notifications/mark-all-read", {});
      setUnreadCount(0);
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    } catch {
      // ignore
    }
  }

  async function handleNotificationClick(notification) {
    if (!notification.is_read) {
      try {
        await api.post(`/notifications/${notification.id}/read`, {});
        setUnreadCount((prev) => Math.max(0, prev - 1));
      } catch {
        // ignore
      }
    }
    if (notification.deal_id) {
      window.location.href = `/deals/${notification.deal_id}`;
    }
  }

  if (!ready) {
    return <div style={{ padding: 40, color: "#8a8578" }}>Načítám…</div>;
  }

  function handleLogout() {
    clearToken();
    router.replace("/login");
  }

  const links = [
    { href: "/", label: "Přehled" },
    { href: "/companies", label: "Firmy" },
    { href: "/contacts", label: "Kontakty" },
    { href: "/documents", label: "Dokumenty" },
    { href: "/settings", label: "Nastavení" },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand" style={{ marginBottom: 4 }}>NAUHEL CRM</div>
        <div
          style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 10,
            letterSpacing: "0.05em",
            color: "var(--ink-400)",
            paddingLeft: 10,
            marginBottom: 26,
            whiteSpace: "nowrap",
          }}
        >
          100%FIRE 100% WOOD
        </div>
        {links.map((link) => (
          <a
            key={link.href}
            href={link.href}
            className={`sidebar-link ${pathname === link.href ? "active" : ""}`}
          >
            {link.label}
          </a>
        ))}

        <div style={{ position: "relative", marginTop: 8 }} ref={panelRef}>
          <button
            onClick={togglePanel}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              width: "100%",
              background: "none",
              border: "none",
              color: "var(--paper-200)",
              padding: "9px 10px",
              borderRadius: 6,
              fontSize: 12.5,
              cursor: "pointer",
              textTransform: "uppercase",
              letterSpacing: "0.05em",
            }}
          >
            🔔 Notifikace
            {unreadCount > 0 && (
              <span
                style={{
                  background: "var(--ember-500)",
                  color: "#fff",
                  borderRadius: 100,
                  fontSize: 10.5,
                  padding: "1px 6px",
                  fontWeight: 700,
                }}
              >
                {unreadCount}
              </span>
            )}
          </button>

          {showPanel && (
            <div
              style={{
                position: "absolute",
                left: "100%",
                bottom: 0,
                marginLeft: 8,
                width: 340,
                maxHeight: 420,
                overflowY: "auto",
                background: "#fff",
                border: "1px solid var(--line)",
                borderRadius: 10,
                boxShadow: "0 8px 24px rgba(0,0,0,0.18)",
                zIndex: 50,
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "10px 14px",
                  borderBottom: "1px solid var(--paper-200)",
                }}
              >
                <strong style={{ fontSize: 13, color: "var(--ink-900)" }}>Notifikace</strong>
                {unreadCount > 0 && (
                  <button
                    onClick={handleMarkAllRead}
                    style={{
                      background: "none",
                      border: "none",
                      color: "var(--ember-500)",
                      fontSize: 12,
                      cursor: "pointer",
                    }}
                  >
                    Označit vše přečtené
                  </button>
                )}
              </div>
              {notifications.length === 0 ? (
                <div style={{ padding: 16, fontSize: 13, color: "var(--ink-400)" }}>Žádné notifikace</div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    onClick={() => handleNotificationClick(n)}
                    style={{
                      padding: "10px 14px",
                      borderBottom: "1px solid var(--paper-200)",
                      cursor: "pointer",
                      background: n.is_read ? "#fff" : "var(--paper-50)",
                    }}
                  >
                    <div style={{ fontSize: 13, color: "var(--ink-900)", marginBottom: 3 }}>{n.message}</div>
                    <div style={{ fontSize: 11, color: "var(--ink-400)" }}>{formatNotifDate(n.created_at)}</div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        <div className="sidebar-footer">
          {user && <div className="sidebar-user">{user.full_name}</div>}
          <button className="logout-btn" onClick={handleLogout}>
            Odhlásit se
          </button>
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
