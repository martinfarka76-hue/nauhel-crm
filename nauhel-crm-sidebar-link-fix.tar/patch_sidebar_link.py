#!/usr/bin/env python3
"""
Odkazy v sidebaru (Prehled/Firmy/Kontakty/Dokumenty/Nastaveni) pouzivaly
obycejny <a href="..."> tag - v Next.js App Routeru to vyvola PLNY RELOAD
stranky prohlizecem misto rychle client-side navigace, coz zpusobovalo
popsany problem (prvni klik "nic neudela", az druhy klik prepne stranku -
zpusobeno tim, ze se pri kazdem kliku znovu spousti cela ProtectedShell
autentizacni kontrola od zacatku).

Reseni: nahradit <a> za Next.js <Link> komponentu.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/components/ProtectedShell.js"

IMPORT_OLD = '''import { useEffect, useState, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";'''

IMPORT_NEW = '''import { useEffect, useState, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";'''

LINKS_OLD = '''        {links.map((link) => (
          <a
            key={link.href}
            href={link.href}
            className={`sidebar-link ${pathname === link.href ? "active" : ""}`}
            style={{ display: "flex", alignItems: "center", gap: 10 }}
          >
            <link.Icon />
            {link.label}
          </a>
        ))}'''

LINKS_NEW = '''        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={`sidebar-link ${pathname === link.href ? "active" : ""}`}
            style={{ display: "flex", alignItems: "center", gap: 10 }}
          >
            <link.Icon />
            {link.label}
          </Link>
        ))}'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(JS_PATH)
    apply_patch(JS_PATH, IMPORT_OLD, IMPORT_NEW, "import next/link")
    apply_patch(JS_PATH, LINKS_OLD, LINKS_NEW, "sidebar odkazy <a> -> <Link>")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "next/link\\|<Link" "{JS_PATH}"')
