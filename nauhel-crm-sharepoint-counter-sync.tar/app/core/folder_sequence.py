import logging

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.folder_sequence import FolderSequence

logger = logging.getLogger("nauhel_crm.folder_sequence")


def peek_next_folder_number(db: Session, year: int) -> int:
    """
    Vrátí příští volné pořadové číslo pro daný rok, ANIŽ by ho spotřebovala
    (počítadlo se nezvyšuje). Vytvoří řádek pro daný rok, pokud ještě
    neexistuje. Volat před pokusem o vytvoření složky na SharePointu.

    Před vrácením čísla se ověří proti DVĚMA zdrojům reality (v tomhle
    pořadí): skutečně použitým číslům u existujících Dealů v databázi,
    a hlavně přímo proti SharePointu (03_Zakázky) - to je nejvyšší
    autorita, protože tam mohly vzniknout složky i mimo CRM (ručně,
    nebo z doby před zavedením CRM). Pokud by počítadlo z nějakého
    důvodu zaostávalo, samo se posune nad nejvyšší zjištěné číslo.
    """
    seq = db.query(FolderSequence).filter(FolderSequence.year == year).first()
    if not seq:
        seq = FolderSequence(year=year, next_number=1)
        db.add(seq)
        db.commit()
        db.refresh(seq)

    from app.models.deal import Deal

    max_used = (
        db.query(func.max(Deal.sharepoint_folder_number))
        .filter(Deal.sharepoint_folder_year == year)
        .scalar()
    )
    if max_used is not None and max_used >= seq.next_number:
        seq.next_number = max_used + 1
        db.commit()
        db.refresh(seq)

    from app.core import sharepoint

    sharepoint_max = sharepoint.get_max_folder_number(year)
    if sharepoint_max >= seq.next_number:
        logger.info(
            "Počítadlo složek pro rok %s bylo pozadu za SharePointem (%s -> %s), opraveno",
            year, seq.next_number, sharepoint_max + 1,
        )
        seq.next_number = sharepoint_max + 1
        db.commit()
        db.refresh(seq)

    return seq.next_number


def confirm_folder_number_used(db: Session, year: int) -> None:
    """
    Skutečně spotřebuje (zvýší) počítadlo - volat AŽ PO úspěšném vytvoření
    složky na SharePointu, ať při selhání nevznikne mezera v číslování.
    """
    seq = db.query(FolderSequence).filter(FolderSequence.year == year).first()
    if seq:
        seq.next_number += 1
        db.commit()
