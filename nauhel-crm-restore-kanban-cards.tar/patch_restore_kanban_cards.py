#!/usr/bin/env python3
"""
OBNOVA ztraceneho redesignu karet Kanbanu (puvodne udelano 7.9.2026, ztratilo
se pri prechodu na novy produkcni server - CSS (.deal-card-footer, kompaktni
padding) prezilo, ale JSX v page.js zustalo na stare verzi karty).

Zmeny:
- barevny levy prouzek (borderLeft) podle STATUS_COLORS[deal.status]
- avatar vlastnika presunuty nahoru vpravo (misto celeho radku "Vlastnik: Jmeno")
- radek Fakturace odstranen z karty (zustava jen v detailu dealu)
- kompaktni footer (Uzavreni + SharePoint ikonka v jednom radku, .deal-card-footer)

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/app/page.js"

JS_OLD = '''                      <a
                        key={deal.id}
                        href={`/deals/${deal.id}`}
                        className="deal-card"
                        style={{ display: "block" }}
                      >
                        <div className="deal-card-top">
                          {domain ? (
                            <>
                              <img
                                src={`https://www.google.com/s2/favicons?domain=${domain}&sz=64`}
                                alt=""
                                className="deal-card-avatar-img"
                                onError={(e) => {
                                  e.target.style.display = "none";
                                  e.target.nextElementSibling.style.display = "flex";
                                }}
                              />
                              <span className="deal-card-avatar" style={{ display: "none" }}>
                                {initial}
                              </span>
                            </>
                          ) : (
                            <span className="deal-card-avatar">{initial}</span>
                          )}
                          <span className="deal-card-company">{companyName}</span>
                        </div>
                        <div className="deal-card-name">{deal.name}</div>
                        <div className="deal-card-price mono">{formatPrice(deal.price)}</div>

                        {(deal.expected_close_date || deal.expected_invoice_date || deal.owner_user_id) && (
                          <div className="deal-card-meta">
                            {deal.expected_close_date && (
                              <div className="deal-card-meta-row">
                                <span className="deal-card-meta-label">Uzavření</span>
                                <span>{formatDateShort(deal.expected_close_date)}</span>
                              </div>
                            )}
                            {deal.expected_invoice_date && (
                              <div className="deal-card-meta-row">
                                <span className="deal-card-meta-label">Fakturace</span>
                                <span>{formatDateShort(deal.expected_invoice_date)}</span>
                              </div>
                            )}
                            {deal.owner_user_id && usersById[deal.owner_user_id] && (
                              <div className="deal-card-meta-row">
                                <span className="deal-card-meta-label">Vlastník</span>
                                <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
                                  <OwnerAvatar user={usersFullById[deal.owner_user_id]} />
                                  <span style={{ color: "var(--ember-600)", fontWeight: 600 }}>
                                    {usersById[deal.owner_user_id]}
                                  </span>
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                        {deal.sharepoint_folder_url && (
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "flex-end",
                              marginTop: 8,
                              paddingTop: 8,
                              borderTop: "1px solid var(--paper-200)",
                            }}
                          >
                            <span
                              role="button"
                              title="Otevřít složku na SharePointu"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                window.open(deal.sharepoint_folder_url, "_blank", "noopener,noreferrer");
                              }}
                              style={{
                                display: "inline-flex",
                                alignItems: "center",
                                justifyContent: "center",
                                width: 24,
                                height: 24,
                                borderRadius: 6,
                                color: "var(--ink-400)",
                                cursor: "pointer",
                              }}
                            >
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M3 7a2 2 0 0 1 2-2h3l2 2h9a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z" />
                              </svg>
                            </span>
                          </div>
                        )}
                      </a>'''

JS_NEW = '''                      <a
                        key={deal.id}
                        href={`/deals/${deal.id}`}
                        className="deal-card"
                        style={{ display: "block", borderLeft: `3px solid ${STATUS_COLORS[deal.status]}` }}
                      >
                        <div className="deal-card-top" style={{ justifyContent: "space-between" }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            {domain ? (
                              <>
                                <img
                                  src={`https://www.google.com/s2/favicons?domain=${domain}&sz=64`}
                                  alt=""
                                  className="deal-card-avatar-img"
                                  onError={(e) => {
                                    e.target.style.display = "none";
                                    e.target.nextElementSibling.style.display = "flex";
                                  }}
                                />
                                <span className="deal-card-avatar" style={{ display: "none" }}>
                                  {initial}
                                </span>
                              </>
                            ) : (
                              <span className="deal-card-avatar">{initial}</span>
                            )}
                            <span className="deal-card-company">{companyName}</span>
                          </div>
                          {deal.owner_user_id && usersById[deal.owner_user_id] && (
                            <span title={usersById[deal.owner_user_id]}>
                              <OwnerAvatar user={usersFullById[deal.owner_user_id]} />
                            </span>
                          )}
                        </div>
                        <div className="deal-card-name">{deal.name}</div>
                        <div className="deal-card-price mono">{formatPrice(deal.price)}</div>

                        {(deal.expected_close_date || deal.sharepoint_folder_url) && (
                          <div className="deal-card-footer">
                            <span>
                              {deal.expected_close_date
                                ? `Uzavření ${formatDateShort(deal.expected_close_date)}`
                                : ""}
                            </span>
                            {deal.sharepoint_folder_url && (
                              <span
                                role="button"
                                title="Otevřít složku na SharePointu"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  window.open(deal.sharepoint_folder_url, "_blank", "noopener,noreferrer");
                                }}
                                style={{
                                  display: "inline-flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  width: 20,
                                  height: 20,
                                  borderRadius: 6,
                                  color: "var(--ink-400)",
                                  cursor: "pointer",
                                }}
                              >
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M3 7a2 2 0 0 1 2-2h3l2 2h9a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z" />
                                </svg>
                              </span>
                            )}
                          </div>
                        )}
                      </a>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(JS_PATH)
    apply_patch(JS_PATH, JS_OLD, JS_NEW, "obnova redesignu karty dealu")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "borderLeft.*STATUS_COLORS" "{JS_PATH}"')
