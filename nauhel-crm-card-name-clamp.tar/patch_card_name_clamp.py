#!/usr/bin/env python3
"""
Nazvy dealu na Kanban kartach ruzne dlouhe zpusobovaly "zubaty" sloupec
(karty s ruznou vyskou vedle sebe). Reseni: omezit .deal-card-name na
max 2 radky s ellipsis (...), cely nazev zustane dostupny jako tooltip
(title atribut) a samozrejme na detailu dealu po rozkliknuti.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodnich
souboru vedle nich (.bak).
"""
import sys

CSS_PATH = "frontend-admin/app/globals.css"
JS_PATH = "frontend-admin/app/page.js"

CSS_OLD = '''.deal-card-name {
  font-size: 14px;
  font-weight: 700;
  color: var(--ember-600, #9c5424);
  margin-bottom: 3px;
  line-height: 1.3;
}'''

CSS_NEW = '''.deal-card-name {
  font-size: 14px;
  font-weight: 700;
  color: var(--ember-600, #9c5424);
  margin-bottom: 3px;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}'''

JS_OLD = '''                        <div className="deal-card-name">{deal.name}</div>'''

JS_NEW = '''                        <div className="deal-card-name" title={deal.name}>{deal.name}</div>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(CSS_PATH)
    backup(JS_PATH)
    apply_patch(CSS_PATH, CSS_OLD, CSS_NEW, "deal-card-name 2-radky ellipsis")
    apply_patch(JS_PATH, JS_OLD, JS_NEW, "deal-card-name title tooltip")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "line-clamp" "{CSS_PATH}"')
    print(f'  grep -n "deal-card-name.*title" "{JS_PATH}"')
