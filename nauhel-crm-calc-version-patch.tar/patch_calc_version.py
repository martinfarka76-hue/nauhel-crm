#!/usr/bin/env python3
"""
Přidá k názvu kalkulace pořadové číslo verze a datum vytvoření
("Kalkulace #2 · 3. 9. 2026 14:23") na detailu dealu.

Bezpečné: mění jen jeden přesně definovaný úsek, ověřuje unikátnost
shody PŘED zápisem, dělá zálohu původního souboru vedle něj.
"""
import sys

PATH = "frontend-admin/app/deals/[id]/page.js"

OLD_HEADER_BLOCK = '''            const items = calcItems[c.id] || [];
            const form = getItemForm(c.id);
            const isExpanded = !!expandedCalcs[c.id];
            return ('''

NEW_HEADER_BLOCK = '''            const items = calcItems[c.id] || [];
            const form = getItemForm(c.id);
            const isExpanded = !!expandedCalcs[c.id];
            const versionNumber = [...calculations]
              .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
              .findIndex((x) => x.id === c.id) + 1;
            return ('''

OLD_TITLE_BLOCK = '''                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span
                      style={{
                        fontSize: 20,
                        color: "var(--ink-600)",
                        width: 22,
                        display: "inline-block",
                        textAlign: "center",
                        lineHeight: 1,
                      }}
                    >
                      {isExpanded ? "▾" : "▸"}
                    </span>
                    <strong style={{ fontSize: 14 }}>
                      {c.product_line || "—"} {c.wood_species ? `/ ${c.wood_species}` : ""}
                    </strong>
                    {c.is_active && <span className="badge" style={{ background: "var(--success)" }}>aktivní</span>}
                  </div>'''

NEW_TITLE_BLOCK = '''                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span
                      style={{
                        fontSize: 20,
                        color: "var(--ink-600)",
                        width: 22,
                        display: "inline-block",
                        textAlign: "center",
                        lineHeight: 1,
                      }}
                    >
                      {isExpanded ? "▾" : "▸"}
                    </span>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <strong style={{ fontSize: 14 }}>
                          {c.product_line || "—"} {c.wood_species ? `/ ${c.wood_species}` : ""}
                        </strong>
                        {c.is_active && <span className="badge" style={{ background: "var(--success)" }}>aktivní</span>}
                      </div>
                      <div style={{ fontSize: 11.5, color: "var(--ink-400)", marginTop: 2 }}>
                        Kalkulace #{versionNumber} · {formatDate(c.created_at)}
                      </div>
                    </div>
                  </div>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil, at nic nerozbiju.")
        sys.exit(1)

    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven.")


if __name__ == "__main__":
    with open(PATH, "r", encoding="utf-8") as f:
        original = f.read()
    with open(PATH + ".bak", "w", encoding="utf-8") as f:
        f.write(original)
    print(f"Zaloha vytvorena: {PATH}.bak")

    apply_patch(PATH, OLD_HEADER_BLOCK, NEW_HEADER_BLOCK, "vypocet versionNumber")
    apply_patch(PATH, OLD_TITLE_BLOCK, NEW_TITLE_BLOCK, "zobrazeni nazvu kalkulace")

    print("\nHotovo. Zkontroluj vystup:")
    print('  grep -n "versionNumber\\|Kalkulace #" "' + PATH + '"')
