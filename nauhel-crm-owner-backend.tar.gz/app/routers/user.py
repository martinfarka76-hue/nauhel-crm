from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.core.dependencies import get_current_user
from app.models.user import User
from app.schemas.auth import UserOut

router = APIRouter(prefix="/users", tags=["users"])


@router.get("", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Seznam uživatelů CRM - pro výběr vlastníka (obchodníka) obchodního případu."""
    return db.query(User).filter(User.is_active.is_(True)).order_by(User.full_name).all()
