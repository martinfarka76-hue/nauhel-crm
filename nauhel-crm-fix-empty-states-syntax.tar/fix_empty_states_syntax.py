#!/usr/bin/env python3
"""
OPRAVA chyby z predchoziho patche: JSX vyzaduje style={{ ... }} (dvojite
zavorky), ale predchozi skript vygeneroval jen style={ ... } (jednoduche) -
to zpusobilo Syntax Error pri buildu na 3 mistech (Dokumenty/Poznamky/Prilohy).

Tento skript najde vsechny 3 vyskyty rozbite verze a opravi je na spravnou
dvojitou zavorku. Bezpecne: overuje presny pocet vyskytu (ocekava 3) PRED
zapisem, zaloha puvodniho souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/app/deals/[id]/page.js"

OLD_BROKEN = '''<div style={
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 6,
                border: "1px dashed var(--paper-200)",
                borderRadius: 10,
                padding: "20px 12px",
                textAlign: "center",
              }>'''

NEW_FIXED = '''<div style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 6,
                border: "1px dashed var(--paper-200)",
                borderRadius: 10,
                padding: "20px 12px",
                textAlign: "center",
              }}>'''

EXPECTED_COUNT = 3


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak2", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak2")


if __name__ == "__main__":
    backup(JS_PATH)

    with open(JS_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    count = content.count(OLD_BROKEN)
    if count == 0:
        print("CHYBA: rozbity usek nebyl nalezen vubec. Mozna uz je opraveny, nebo se lisi formatovani. Nic jsem nezmenil.")
        sys.exit(1)
    if count != EXPECTED_COUNT:
        print(f"POZOR: rozbity usek nalezen {count}x, cekal jsem {EXPECTED_COUNT}x. Opravuji vsechny nalezene vyskyty, ale zkontroluj vysledek dukladneji.")

    content = content.replace(OLD_BROKEN, NEW_FIXED)
    with open(JS_PATH, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: opraveno {count}x v {JS_PATH}.")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "style={{{{" "{JS_PATH}" | grep -c "dashed"')
    print(f'  (mel by ukazat cislo 3 - potvrzuje, ze vsechny 3 mista maji spravne dvojite zavorky)')
