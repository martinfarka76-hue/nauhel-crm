#!/usr/bin/env python3
"""
Kompaktnejsi hlavicka Prehledu (dashboardu) - 4 samostatne "patra"
(nadpis+tlacitka, vyhledavani, filtry, follow-up pruh) sloucena na 3,
s mensim nadpisem, at se Kanban posune vys.

DULEZITE: .page-title CSS trida se NEMENI (pouziva se na 8 dalsich
strankach - Firmy, Kontakty, Nastaveni, Dokumenty, Reporty, detail
dealu/firmy) - font-size se zmensuje jen inline stylem na tomhle
jednom konkretnim <h1>.

Zmeny:
1) mensi nadpis (fontSize 18 inline) + mensi mezera pod hornim radkem
   (marginBottom 16 -> 10)
2) sloucen radek vyhledavani a radek filtru do jednoho flex radku se
   zalamovanim (flexWrap), odstranenim oddelujiciho </div><div> mezi nimi

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/app/page.js"

HEADER_OLD = '''      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          rowGap: 10,
          marginBottom: 16,
        }}
      >
        <h1 className="page-title" style={{ margin: 0 }}>
          Přehled obchodních případů
        </h1>'''

HEADER_NEW = '''      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          rowGap: 10,
          marginBottom: 10,
        }}
      >
        <h1 className="page-title" style={{ margin: 0, fontSize: 18 }}>
          Přehled obchodních případů
        </h1>'''

ROW_STYLE_OLD = '''        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <div style={{ position: "relative" }}>'''

ROW_STYLE_NEW = '''        <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
          <div style={{ position: "relative" }}>'''

MERGE_OLD = '''              Export do Excelu (CSV)
            </button>
          )}
        </div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <FilterChip label="Vlastník">'''

MERGE_NEW = '''              Export do Excelu (CSV)
            </button>
          )}
          <FilterChip label="Vlastník">'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(JS_PATH)
    apply_patch(JS_PATH, HEADER_OLD, HEADER_NEW, "mensi nadpis + mezera")
    apply_patch(JS_PATH, ROW_STYLE_OLD, ROW_STYLE_NEW, "radek vyhledavani - flexWrap misto marginBottom")
    apply_patch(JS_PATH, MERGE_OLD, MERGE_NEW, "slouceni vyhledavani a filtru do jednoho radku")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "fontSize: 18" "{JS_PATH}"')
