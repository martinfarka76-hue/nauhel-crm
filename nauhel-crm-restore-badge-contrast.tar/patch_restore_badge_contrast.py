#!/usr/bin/env python3
"""
OBNOVA ztracene funkce - getBadgeTextColor() existuje v constants.js, ale
jeji POUZITI zmizelo na obou mistech, kde se STATUS_COLORS pouziva jako
pozadi badge (Seznam view na Prehledu, status badge na detailu dealu).
Dusledek: bily text na svetle barve "Nabidka" (#e0b478, kontrast jen 1.9)
je prakticky necitelny - overeno na screenshotu 17.9.2026.

Stejny vzorec jako predchozi regrese (Kalkulace verze) - kod v constants.js
prezil, ale konkretni pouziti v page.js / deals/[id]/page.js bylo pri
pozdejsi praci prepsano/ztraceno.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodnich
souboru vedle nich (.bak).
"""
import sys

LIST_PATH = "frontend-admin/app/page.js"
DETAIL_PATH = "frontend-admin/app/deals/[id]/page.js"

LIST_IMPORT_OLD = 'import { DEAL_STATUSES, STATUS_COLORS } from "@/lib/constants";'
LIST_IMPORT_NEW = 'import { DEAL_STATUSES, STATUS_COLORS, getBadgeTextColor } from "@/lib/constants";'

LIST_BADGE_OLD = '''                        <span className="badge" style={{ background: STATUS_COLORS[deal.status] }}>
                          {deal.status}
                        </span>'''

LIST_BADGE_NEW = '''                        <span
                          className="badge"
                          style={{
                            background: STATUS_COLORS[deal.status],
                            color: getBadgeTextColor(STATUS_COLORS[deal.status]),
                          }}
                        >
                          {deal.status}
                        </span>'''

DETAIL_IMPORT_OLD = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS } from "@/lib/constants";'
DETAIL_IMPORT_NEW = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS, getBadgeTextColor } from "@/lib/constants";'

DETAIL_BADGE_OLD = '''          <span className="badge" style={{ background: STATUS_COLORS[deal.status], fontSize: 13 }}>
            {deal.status}
          </span>'''

DETAIL_BADGE_NEW = '''          <span
            className="badge"
            style={{
              background: STATUS_COLORS[deal.status],
              color: getBadgeTextColor(STATUS_COLORS[deal.status]),
              fontSize: 13,
            }}
          >
            {deal.status}
          </span>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(LIST_PATH)
    backup(DETAIL_PATH)

    apply_patch(LIST_PATH, LIST_IMPORT_OLD, LIST_IMPORT_NEW, "import v Seznam view")
    apply_patch(LIST_PATH, LIST_BADGE_OLD, LIST_BADGE_NEW, "badge barva textu v Seznam view")
    apply_patch(DETAIL_PATH, DETAIL_IMPORT_OLD, DETAIL_IMPORT_NEW, "import v detailu dealu")
    apply_patch(DETAIL_PATH, DETAIL_BADGE_OLD, DETAIL_BADGE_NEW, "badge barva textu v detailu dealu")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "getBadgeTextColor" "{LIST_PATH}" "{DETAIL_PATH}"')
