"""
Integrace s iDokladem (vystavování skutečných daňových dokladů). OAuth2
"client credentials" flow - žádná interakce uživatele není potřeba.

Vyžaduje proměnné prostředí IDOKLAD_CLIENT_ID a IDOKLAD_CLIENT_SECRET.
Pokud nejsou nastavené, veškerá volání se tiše přeskočí (jen zaloguje
info) - ať appka funguje i před dokončením nastavení, stejně jako
u MS Graph integrace.

POZNÁMKA: přesné názvy polí u položek faktury (zejména DPH) nejsou
stoprocentně ověřené z oficiální dokumentace (ta je jen jako interaktivní
JS aplikace, ne staticky čitelná). Ladí se podle skutečných odpovědí
API při prvním ostrém testu.
"""
import os
import time
import logging
import httpx

logger = logging.getLogger("nauhel_crm.idoklad")

_token_cache = {"access_token": None, "expires_at": 0.0}

TOKEN_URL = "https://identity.idoklad.cz/server/connect/token"
API_BASE = "https://api.idoklad.cz/v3"


def is_configured() -> bool:
    return bool(os.environ.get("IDOKLAD_CLIENT_ID")) and bool(os.environ.get("IDOKLAD_CLIENT_SECRET"))


def _get_access_token() -> str:
    now = time.time()
    if _token_cache["access_token"] and _token_cache["expires_at"] > now + 60:
        return _token_cache["access_token"]

    client_id = os.environ["IDOKLAD_CLIENT_ID"]
    client_secret = os.environ["IDOKLAD_CLIENT_SECRET"]

    data = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "scope": "idoklad_api",
    }
    resp = httpx.post(TOKEN_URL, data=data, timeout=15.0)
    resp.raise_for_status()
    token_data = resp.json()
    _token_cache["access_token"] = token_data["access_token"]
    _token_cache["expires_at"] = now + token_data.get("expires_in", 1800)
    logger.info("iDoklad: nový access token získán")
    return _token_cache["access_token"]


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {_get_access_token()}",
        "Content-Type": "application/json",
    }


def find_or_create_contact(ico: str, name: str, address: str = None) -> int | None:
    """
    Najde odběratele v iDokladu podle IČO. Pokud neexistuje, vytvoří ho.
    Vrací interní ID kontaktu v iDokladu (int), nebo None při selhání.
    """
    if not is_configured():
        logger.info("iDoklad není nakonfigurován - přeskakuji find_or_create_contact")
        return None

    try:
        # Hledání podle IČO
        if ico:
            resp = httpx.get(
                f"{API_BASE}/Contacts",
                params={"filter": f"CompanyRegistrationNumber~eq~{ico}"},
                headers=_headers(),
                timeout=15.0,
            )
            if resp.status_code >= 400:
                logger.error("iDoklad: GET /Contacts selhalo (%s): %s", resp.status_code, resp.text)
            resp.raise_for_status()
            result = resp.json()
            items = result.get("Data") or result.get("Items") or []
            if items:
                contact_id = items[0].get("Id")
                logger.info("iDoklad: nalezen existující kontakt %s pro IČO %s", contact_id, ico)
                return contact_id

        # Nenalezeno (nebo bez IČO) - vytvoř nový kontakt
        payload = {"CompanyName": name}
        if ico:
            payload["CompanyRegistrationNumber"] = ico
        if address:
            payload["Street"] = address

        resp = httpx.post(f"{API_BASE}/Contacts", json=payload, headers=_headers(), timeout=15.0)
        if resp.status_code >= 400:
            logger.error("iDoklad: POST /Contacts selhalo (%s): %s", resp.status_code, resp.text)
        resp.raise_for_status()
        contact_id = resp.json().get("Id")
        logger.info("iDoklad: vytvořen nový kontakt %s (%s)", contact_id, name)
        return contact_id
    except Exception:
        logger.exception("iDoklad: find_or_create_contact selhalo pro '%s' (IČO %s)", name, ico)
        return None


def create_issued_invoice(
    purchaser_id: int,
    item_name: str,
    amount: float,
    vat_rate: float,
    is_advance_invoice: bool = False,
) -> dict | None:
    """
    Vytvoří vydanou fakturu v iDokladu s jednou položkou (částka je
    včetně DPH - IsVatMovement/PriceType se řeší podle konkrétní odpovědi
    API při testování). Vrací {"id", "number", "pdf_url"} nebo None při
    selhání/nenakonfigurování.
    """
    if not is_configured():
        logger.info("iDoklad není nakonfigurován - faktura se nevystavuje (%s)", item_name)
        return None

    try:
        vat_rate_percent = round(float(vat_rate) * 100)
        payload = {
            "PurchaserId": purchaser_id,
            "IssuedInvoiceItems": [
                {
                    "Name": item_name,
                    "Amount": 1,
                    "UnitPrice": amount,
                    "PriceType": 1,  # 1 = cena s DPH (dle konvence iDoklad - ověřit při testu)
                    "VatRatePercent": vat_rate_percent,
                }
            ],
        }
        resp = httpx.post(f"{API_BASE}/IssuedInvoices", json=payload, headers=_headers(), timeout=15.0)
        if resp.status_code >= 400:
            logger.error("iDoklad: POST /IssuedInvoices selhalo (%s): %s", resp.status_code, resp.text)
        resp.raise_for_status()
        data = resp.json()
        invoice_id = data.get("Id")
        invoice_number = data.get("DocumentNumber") or data.get("Number")
        pdf_url = f"{API_BASE}/IssuedInvoices/{invoice_id}/GetPdf" if invoice_id else None
        logger.info("iDoklad: faktura vystavena - ID %s, číslo %s", invoice_id, invoice_number)
        return {"id": invoice_id, "number": invoice_number, "pdf_url": pdf_url}
    except Exception:
        logger.exception("iDoklad: create_issued_invoice selhalo (%s, %.2f Kč)", item_name, amount)
        return None
