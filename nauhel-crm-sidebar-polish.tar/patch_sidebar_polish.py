#!/usr/bin/env python3
"""
Doladeni sidebaru:
1) .sidebar-link padding 9px->7px (kompaktnejsi polozky menu)
2) tagline "100%FIRE 100% WOOD" marginBottom 26->20 (tesnejsi navazani na menu)
3) radek logo+zvonecek dostane jemnou oddelovaci linku dole (border-bottom),
   at je vizualne jasne oddeleny od menu pod nim

Cistokosmeticka uprava, zadna nova logika.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodnich
souboru vedle nich (.bak).
"""
import sys

CSS_PATH = "frontend-admin/app/globals.css"
JS_PATH = "frontend-admin/components/ProtectedShell.js"

CSS_OLD = '''.sidebar-link {
  padding: 9px 10px;
  border-radius: 6px;
  color: var(--paper-200);
  font-size: 12.5px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  transition: background 0.15s ease, color 0.15s ease;
}'''

CSS_NEW = '''.sidebar-link {
  padding: 7px 10px;
  border-radius: 6px;
  color: var(--paper-200);
  font-size: 12.5px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  transition: background 0.15s ease, color 0.15s ease;
}'''

HEADER_ROW_OLD = '''        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, marginBottom: 4 }}>'''

HEADER_ROW_NEW = '''        <div
          style={{
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "space-between",
            gap: 16,
            marginBottom: 14,
            paddingBottom: 14,
            borderBottom: "1px solid rgba(255,255,255,0.08)",
          }}
        >'''

TAGLINE_OLD = '''        <div
          style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 10,
            letterSpacing: "0.05em",
            color: "var(--ink-400)",
            paddingLeft: 10,
            marginBottom: 26,
            whiteSpace: "nowrap",
          }}
        >
          100%FIRE 100% WOOD
        </div>'''

TAGLINE_NEW = '''        <div
          style={{
            fontFamily: "'IBM Plex Mono', monospace",
            fontSize: 10,
            letterSpacing: "0.05em",
            color: "var(--ink-400)",
            paddingLeft: 10,
            marginBottom: 20,
            whiteSpace: "nowrap",
          }}
        >
          100%FIRE 100% WOOD
        </div>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(CSS_PATH)
    backup(JS_PATH)

    apply_patch(CSS_PATH, CSS_OLD, CSS_NEW, "sidebar-link padding")
    apply_patch(JS_PATH, HEADER_ROW_OLD, HEADER_ROW_NEW, "oddelovaci linka pod logem+zvoneckem")
    apply_patch(JS_PATH, TAGLINE_OLD, TAGLINE_NEW, "tagline marginBottom")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "rgba(255,255,255,0.08)" "{JS_PATH}"')
    print(f'  grep -n "padding: 7px 10px" "{CSS_PATH}"')
