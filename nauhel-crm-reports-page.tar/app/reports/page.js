"use client";

import { useEffect, useState } from "react";
import ProtectedShell from "@/components/ProtectedShell";
import { api } from "@/lib/api";

const MONTH_NAMES = ["Led", "Úno", "Bře", "Dub", "Kvě", "Čer", "Čvc", "Srp", "Zář", "Říj", "Lis", "Pro"];

const ACTIVE_STATUSES = [
  "Lead",
  "Kvalifikovaný lead",
  "Nabídka",
  "Objednávka",
  "Zálohová faktura",
  "Vyrobeno",
];

function buildMonthRange(startOffset, endOffset) {
  const now = new Date();
  const result = [];
  for (let i = startOffset; i <= endOffset; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const year = d.getFullYear();
    const month = d.getMonth();
    const key = `${year}-${String(month + 1).padStart(2, "0")}`;
    const label = `${MONTH_NAMES[month]} ${String(year).slice(2)}`;
    result.push({ key, label, isCurrent: i === 0 });
  }
  return result;
}

function computeMonthlyData(deals, dateField, monthRange, { weighted = false, statusFilter = null, probabilities = {} } = {}) {
  const buckets = {};
  monthRange.forEach((m) => (buckets[m.key] = 0));

  deals.forEach((d) => {
    const dateVal = d[dateField];
    if (!dateVal) return;
    if (statusFilter && !statusFilter.includes(d.status)) return;
    const key = dateVal.slice(0, 7);
    if (!(key in buckets)) return;
    const price = Number(d.price) || 0;
    const value = weighted ? price * ((probabilities[d.status] ?? 0) / 100) : price;
    buckets[key] += value;
  });

  return monthRange.map((m) => ({ month: m.key, label: m.label, value: buckets[m.key], isCurrent: m.isCurrent }));
}

function formatKc(value) {
  if (value >= 1_000_000) return (value / 1_000_000).toFixed(1).replace(".", ",") + " M Kč";
  if (value >= 1000) return Math.round(value / 1000) + " tis. Kč";
  if (value === 0) return "";
  return Math.round(value) + " Kč";
}

function MonthlyBarChart({ title, description, data, color }) {
  const maxValue = Math.max(...data.map((d) => d.value), 1);
  const total = data.reduce((sum, d) => sum + d.value, 0);

  return (
    <div className="card" style={{ marginBottom: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
        <div style={{ fontWeight: 600 }}>{title}</div>
        <div style={{ fontSize: 13, fontWeight: 700, color: "var(--ember-600)" }}>{formatKc(total) || "0 Kč"}</div>
      </div>
      {description && (
        <div style={{ fontSize: 12, color: "var(--ink-600)", marginBottom: 16 }}>{description}</div>
      )}
      <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 180 }}>
        {data.map((d) => (
          <div
            key={d.month}
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              height: "100%",
              justifyContent: "flex-end",
            }}
          >
            <div style={{ fontSize: 10.5, color: "var(--ink-600)", marginBottom: 4, whiteSpace: "nowrap" }}>
              {formatKc(d.value)}
            </div>
            <div
              title={`${d.label}: ${Math.round(d.value).toLocaleString("cs-CZ")} Kč`}
              style={{
                width: "100%",
                height: `${d.value > 0 ? Math.max((d.value / maxValue) * 100, 3) : 0}%`,
                background: d.isCurrent ? color : color,
                opacity: d.isCurrent ? 1 : 0.75,
                borderRadius: "4px 4px 0 0",
                minHeight: d.value > 0 ? 3 : 0,
              }}
            />
            <div
              style={{
                fontSize: 11,
                color: d.isCurrent ? "var(--ink-900)" : "var(--ink-400)",
                fontWeight: d.isCurrent ? 700 : 400,
                marginTop: 6,
                whiteSpace: "nowrap",
              }}
            >
              {d.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ReportsPage() {
  const [deals, setDeals] = useState([]);
  const [probabilities, setProbabilities] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.get("/deals"), api.get("/stage-config")])
      .then(([dealsData, stageConfig]) => {
        setDeals(dealsData);
        const probMap = {};
        stageConfig.forEach((s) => (probMap[s.stage_name] = s.probability_percent));
        setProbabilities(probMap);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <ProtectedShell>
        <div className="empty-state">Načítám…</div>
      </ProtectedShell>
    );
  }

  const historyRange = buildMonthRange(-11, 0);
  const forecastRange = buildMonthRange(0, 11);

  const newDealsData = computeMonthlyData(deals, "created_at", historyRange);
  const invoiceForecastData = computeMonthlyData(deals, "expected_invoice_date", forecastRange, {
    weighted: true,
    statusFilter: ACTIVE_STATUSES,
    probabilities,
  });
  const closeForecastData = computeMonthlyData(deals, "expected_close_date", forecastRange, {
    weighted: true,
    statusFilter: ACTIVE_STATUSES,
    probabilities,
  });
  const invoicedHistoryData = computeMonthlyData(deals, "expected_invoice_date", historyRange, {
    statusFilter: ["Fakturováno"],
  });

  return (
    <ProtectedShell>
      <h1 className="page-title">Reporty</h1>
      <p className="page-subtitle">Plánování obchodů a fakturací - historie i výhled dopředu</p>

      {error && <div className="error-banner">{error}</div>}

      <MonthlyBarChart
        title="Nové obchodní případy podle měsíce"
        description="Objem (cena) nově vytvořených případů - posledních 12 měsíců, podle data vzniku"
        data={newDealsData}
        color="var(--ember-500)"
      />

      <MonthlyBarChart
        title="Výhled fakturací podle měsíce (vážený objem)"
        description="Odhadovaná fakturace u aktivních případů (bez Fakturováno a Ztraceno), vážená pravděpodobností stavu - příštích 12 měsíců"
        data={invoiceForecastData}
        color="#2f6f4f"
      />

      <MonthlyBarChart
        title="Výhled uzavření podle měsíce (vážený objem)"
        description="Odhadované uzavření u aktivních případů, vážené pravděpodobností stavu - příštích 12 měsíců"
        data={closeForecastData}
        color="#64748b"
      />

      <MonthlyBarChart
        title="Historie fakturovaného objemu"
        description="Skutečně fakturované případy podle odhadovaného data fakturace - posledních 12 měsíců"
        data={invoicedHistoryData}
        color="#1f5c3a"
      />
    </ProtectedShell>
  );
}
