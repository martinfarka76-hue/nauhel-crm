#!/usr/bin/env python3
"""
Dlouhe sloupce Kanbanu (napr. 22 dealu v Lead) nedavaly zadny signal, ze je
pod viditelnou casti dalsi obsah k prescrollovani. Reseni: cisty CSS trik
(zname jako "scroll shadow"/"fade" technika) na .kanban-cards - kombinace
dvou pozadi:
- "cover" gradient (attachment: local, tzn. pohybuje se S obsahem) - tvori
  plnou barvu presne u posledniho pixelu obsahu
- "shadow" gradient (attachment: scroll, tzn. pevne u spodku viditelneho
  boxu) - jemny stin

Kdyz je pod viditelnou casti dalsi obsah, cover gradient je "schovany" pod
viditelnou oblasti (je u SKUTECNEHO konce obsahu, ktery jeste neni videt),
takze stin je videt. Jakmile user doscrolluje uplne dolu (nebo kdyz se
vsechny karty vejdou bez scrollu), cover gradient prekryje stin -> zmizi
automaticky. Zadny JS, zadne merovani, zadne riziko.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

CSS_PATH = "frontend-admin/app/globals.css"

CSS_OLD = '''.kanban-cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
  overflow-y: auto;
  flex: 1;
  min-height: 0;
  padding-right: 4px;
}'''

CSS_NEW = '''.kanban-cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
  overflow-y: auto;
  flex: 1;
  min-height: 0;
  padding-right: 4px;
  background-image:
    linear-gradient(to bottom, transparent, var(--paper-50) 70%),
    linear-gradient(to top, rgba(14, 12, 9, 0.18), rgba(14, 12, 9, 0));
  background-repeat: no-repeat;
  background-position: bottom, bottom;
  background-size: 100% 40px, 100% 16px;
  background-attachment: local, scroll;
}'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(CSS_PATH)
    apply_patch(CSS_PATH, CSS_OLD, CSS_NEW, "kanban-cards scroll shadow")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "background-attachment" "{CSS_PATH}"')
