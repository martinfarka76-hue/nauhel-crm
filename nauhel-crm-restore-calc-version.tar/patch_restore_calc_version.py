#!/usr/bin/env python3
"""
OBNOVA ztracene funkce "Kalkulace #N - datum vytvoreni" pod nazvem drfeviny
na detailu dealu (puvodne pridano 7.9.2026, zmizelo pri pozdejsi praci na
slevach/servisnim ceniku partnera - overeno 16.9.2026 ze versionNumber
v souboru vubec neexistuje).

Zmeny:
- vypocet versionNumber (poradi kalkulace podle created_at) pred return
- pod nazvem drfeviny + badge "aktivni" pridan radek "Kalkulace #N · datum"

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/app/deals/[id]/page.js"

HEADER_OLD = '''          calculations.map((c) => {
            const items = calcItems[c.id] || [];
            const form = getItemForm(c.id);
            const isExpanded = !!expandedCalcs[c.id];
            return ('''

HEADER_NEW = '''          calculations.map((c) => {
            const items = calcItems[c.id] || [];
            const form = getItemForm(c.id);
            const isExpanded = !!expandedCalcs[c.id];
            const versionNumber = [...calculations]
              .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
              .findIndex((x) => x.id === c.id) + 1;
            return ('''

TITLE_OLD = '''                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span
                      style={{
                        fontSize: 20,
                        color: "var(--ink-600)",
                        width: 22,
                        display: "inline-block",
                        textAlign: "center",
                        lineHeight: 1,
                      }}
                    >
                      {isExpanded ? "▾" : "▸"}
                    </span>
                    <strong style={{ fontSize: 14 }}>
                      {c.product_line || "—"} {c.wood_species ? `/ ${c.wood_species}` : ""}
                    </strong>
                    {c.is_active && <span className="badge" style={{ background: "var(--success)" }}>aktivní</span>}
                  </div>
                  <strong className="mono" style={{ fontSize: 14 }}>{money(c.price_with_vat)}</strong>
                </div>'''

TITLE_NEW = '''                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span
                      style={{
                        fontSize: 20,
                        color: "var(--ink-600)",
                        width: 22,
                        display: "inline-block",
                        textAlign: "center",
                        lineHeight: 1,
                      }}
                    >
                      {isExpanded ? "▾" : "▸"}
                    </span>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <strong style={{ fontSize: 14 }}>
                          {c.product_line || "—"} {c.wood_species ? `/ ${c.wood_species}` : ""}
                        </strong>
                        {c.is_active && <span className="badge" style={{ background: "var(--success)" }}>aktivní</span>}
                      </div>
                      <div style={{ fontSize: 11.5, color: "var(--ink-400)", marginTop: 2 }}>
                        Kalkulace #{versionNumber} · {formatDate(c.created_at)}
                      </div>
                    </div>
                  </div>
                  <strong className="mono" style={{ fontSize: 14 }}>{money(c.price_with_vat)}</strong>
                </div>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(JS_PATH)
    apply_patch(JS_PATH, HEADER_OLD, HEADER_NEW, "vypocet versionNumber")
    apply_patch(JS_PATH, TITLE_OLD, TITLE_NEW, "zobrazeni Kalkulace #N a data")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "versionNumber\\|Kalkulace #" "{JS_PATH}"')
