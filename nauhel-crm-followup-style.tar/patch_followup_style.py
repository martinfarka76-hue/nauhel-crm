#!/usr/bin/env python3
"""
Dve vylepseni follow-up pruhu na Prehledu:

1) Graficke odliseni - misto bezne bile .card komponenty dostane stejny
   broskvovy/ember vzhled jako karta "Co dal" na detailu dealu (uz zavedeny
   vzor v appce pro "tohle potrebuje pozornost"), at to na prvni pohled
   nesplyva s Kanban kartami pod tim.

2) Chipy s nazvem dealu dostanou vetsi maxWidth (220 -> 320), at se u vetsiny
   bezne dlouhych nazvu neorizne text uprostred slova. Title tooltip s
   celym nazvem uz existuje, tim se nic nemeni.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/app/page.js"

CARD_OLD = '''          <div className="card" style={{ marginBottom: 12, flexShrink: 0, padding: "8px 12px" }}>'''

CARD_NEW = '''          <div
            className="card"
            style={{
              marginBottom: 12,
              flexShrink: 0,
              padding: "8px 12px",
              background: "#fdf3ec",
              borderColor: "var(--ember-500)",
            }}
          >'''

WIDTH_OLD = '''                      borderRadius: 999,
                      cursor: "pointer",
                      fontSize: 12,
                      maxWidth: 220,
                    }}'''

WIDTH_NEW = '''                      borderRadius: 999,
                      cursor: "pointer",
                      fontSize: 12,
                      maxWidth: 320,
                    }}'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(JS_PATH)
    apply_patch(JS_PATH, CARD_OLD, CARD_NEW, "follow-up pruh - broskvove pozadi + ember ramecek")
    apply_patch(JS_PATH, WIDTH_OLD, WIDTH_NEW, "follow-up chip maxWidth 220 -> 320")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "fdf3ec\\|maxWidth: 320" "{JS_PATH}"')
