"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import ProtectedShell from "@/components/ProtectedShell";
import { api } from "@/lib/api";
import { normalizeForSearch } from "@/lib/search";

function getDomain(url) {
  if (!url) return null;
  try {
    let u = url.trim();
    if (!/^https?:\/\//i.test(u)) u = "https://" + u;
    return new URL(u).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function CompanyAvatar({ name, website }) {
  const domain = getDomain(website);
  const initial = name ? name.charAt(0).toUpperCase() : "?";
  const [imgFailed, setImgFailed] = useState(false);

  if (domain && !imgFailed) {
    return (
      <img
        src={`https://www.google.com/s2/favicons?domain=${domain}&sz=64`}
        alt=""
        onError={() => setImgFailed(true)}
        style={{
          width: 22,
          height: 22,
          borderRadius: "50%",
          flexShrink: 0,
          objectFit: "cover",
          background: "var(--paper-100)",
          border: "1px solid var(--paper-200)",
        }}
      />
    );
  }
  return (
    <span
      style={{
        width: 22,
        height: 22,
        borderRadius: "50%",
        flexShrink: 0,
        background: "var(--ember-500)",
        color: "#fff",
        fontSize: 10.5,
        fontWeight: 700,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {initial}
    </span>
  );
}

export default function CompaniesPage() {
  const router = useRouter();
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [form, setForm] = useState({ name: "", ico: "", dic: "", website: "", address: "" });
  const [saving, setSaving] = useState(false);
  const [aresLoading, setAresLoading] = useState(false);
  const [aresError, setAresError] = useState("");
  const [dupMatches, setDupMatches] = useState([]);

  function loadCompanies() {
    setLoading(true);
    api
      .get("/companies")
      .then((data) => setCompanies([...data].sort((a, b) => a.name.localeCompare(b.name, "cs"))))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(loadCompanies, []);

  // Kontrola možné duplicity - jen upozornění, nic neblokuje. Debounce 400ms,
  // ať se nedotazuje na každé písmeno.
  useEffect(() => {
    if (!showForm || (!form.name.trim() && !form.ico.trim())) {
      setDupMatches([]);
      return;
    }
    const timer = setTimeout(() => {
      const params = new URLSearchParams();
      if (form.name.trim()) params.set("name", form.name.trim());
      if (form.ico.trim()) params.set("ico", form.ico.trim());
      api
        .get(`/companies/check-duplicate?${params.toString()}`)
        .then((matches) => setDupMatches(matches))
        .catch(() => setDupMatches([]));
    }, 400);
    return () => clearTimeout(timer);
  }, [form.name, form.ico, showForm]);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api.post("/companies", form);
      setForm({ name: "", ico: "", dic: "", website: "", address: "" });
      setDupMatches([]);
      setShowForm(false);
      loadCompanies();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAresLookup() {
    if (!form.ico) {
      setAresError("Nejdřív vyplň IČO.");
      return;
    }
    setAresLoading(true);
    setAresError("");
    try {
      const result = await api.get(`/ares/${form.ico}`);
      setForm({
        ...form,
        name: result.name || form.name,
        address: result.address || form.address,
        dic: result.dic_guess || form.dic,
      });
    } catch (err) {
      setAresError(err.message);
    } finally {
      setAresLoading(false);
    }
  }

  return (
    <ProtectedShell>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <h1 className="page-title">Firmy</h1>
          <p className="page-subtitle">Zákazníci a jejich údaje</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Zrušit" : "+ Nová firma"}
        </button>
      </div>

      {error && <div className="error-banner">{error}</div>}

      {showForm && (
        <div className="card" style={{ marginBottom: 20 }}>
          <form onSubmit={handleCreate}>
            <div className="field">
              <label>IČO</label>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  value={form.ico}
                  onChange={(e) => setForm({ ...form, ico: e.target.value })}
                  style={{ flex: 1 }}
                />
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={handleAresLookup}
                  disabled={aresLoading}
                >
                  {aresLoading ? "Hledám…" : "Vyhledat v ARES"}
                </button>
              </div>
              {aresError && (
                <div style={{ fontSize: 12.5, color: "var(--danger)", marginTop: 4 }}>{aresError}</div>
              )}
              <div style={{ fontSize: 12, color: "var(--ink-400)", marginTop: 4 }}>
                Zadej IČO a klikni na "Vyhledat v ARES" - doplní název a adresu. DIČ je jen odhad,
                zkontroluj prosím jeho správnost.
              </div>
            </div>
            <div className="field">
              <label>Název firmy *</label>
              <input
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            {dupMatches.length > 0 && (
              <div
                style={{
                  background: "#fdf3ec",
                  border: "1px solid var(--ember-500)",
                  borderRadius: 8,
                  padding: "10px 12px",
                  marginBottom: 14,
                  fontSize: 12.5,
                }}
              >
                <strong>⚠️ Možná duplicita</strong> - podobná firma už v CRM je:
                <ul style={{ margin: "6px 0 0", paddingLeft: 18 }}>
                  {dupMatches.map((m) => (
                    <li key={m.id}>
                      <a
                        href={`/companies/${m.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ color: "var(--ember-600)", textDecoration: "underline" }}
                      >
                        {m.name} {m.ico ? `(IČO ${m.ico})` : ""}
                      </a>
                    </li>
                  ))}
                </ul>
                <div style={{ marginTop: 4, color: "var(--ink-600)" }}>
                  Pokud jde skutečně o jinou firmu, klidně pokračuj v ukládání.
                </div>
              </div>
            )}
            <div className="field">
              <label>DIČ</label>
              <input
                value={form.dic}
                onChange={(e) => setForm({ ...form, dic: e.target.value })}
              />
            </div>
            <div className="field">
              <label>Web</label>
              <input
                value={form.website}
                onChange={(e) => setForm({ ...form, website: e.target.value })}
                placeholder="např. nauhel.cz"
              />
            </div>
            <div className="field">
              <label>Adresa</label>
              <input
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
              />
            </div>
            <button className="btn btn-primary" type="submit" disabled={saving}>
              {saving ? "Ukládám…" : "Uložit firmu"}
            </button>
          </form>
        </div>
      )}

      {!loading && companies.length > 0 && (
        <div style={{ marginBottom: 14 }}>
          <input
            type="text"
            placeholder="Hledat podle názvu, IČO nebo adresy…"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              padding: "8px 12px",
              fontSize: 13,
              borderRadius: 8,
              border: "1px solid var(--paper-200)",
              width: 320,
            }}
          />
        </div>
      )}

      {loading ? (
        <div className="empty-state">Načítám…</div>
      ) : companies.length === 0 ? (
        <div className="empty-state">Zatím žádné firmy. Přidej první přes tlačítko výše.</div>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Název</th>
              <th>IČO</th>
              <th>Adresa</th>
            </tr>
          </thead>
          <tbody>
            {companies
              .filter((c) => {
                if (!searchQuery.trim()) return true;
                const q = normalizeForSearch(searchQuery.trim());
                return (
                  normalizeForSearch(c.name).includes(q) ||
                  normalizeForSearch(c.ico).includes(q) ||
                  normalizeForSearch(c.address).includes(q)
                );
              })
              .map((c) => (
              <tr
                key={c.id}
                className="clickable"
                onClick={() => router.push(`/companies/${c.id}`)}
              >
                <td style={{ fontWeight: 600 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <CompanyAvatar name={c.name} website={c.website} />
                    {c.name}
                  </div>
                </td>
                <td className="mono">{c.ico || "—"}</td>
                <td>{c.address || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </ProtectedShell>
  );
}
