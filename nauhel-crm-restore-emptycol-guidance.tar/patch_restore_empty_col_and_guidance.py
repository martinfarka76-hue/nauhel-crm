#!/usr/bin/env python3
"""
OBNOVA dvou dalsich ztracenych casti ze 7.9. davky:

1) page.js - prazdny sloupec Kanbanu ("Zadne pripady") mel mit dashed box
   misto proste seedeho textu - vratilo se to na puvodni holy text.

2) deals/[id]/page.js - karta "Co dal" mela mit pozadi/border podle
   STATUS_COLORS[deal.status] (pres hexToRgba), ale zustalo to na natvrdo
   pevne barve "#fdf3ec"/"var(--ember-500)" pro vsechny stavy krome
   Ztraceno. Import hexToRgba v tomto souboru chybi (getBadgeTextColor
   uz byl obnoven v predchozim kroku, hexToRgba ne).

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodnich
souboru vedle nich (.bak).
"""
import sys

LIST_PATH = "frontend-admin/app/page.js"
DETAIL_PATH = "frontend-admin/app/deals/[id]/page.js"

EMPTY_COL_OLD = '''                    <div style={{ fontSize: 12, color: "var(--ink-400)", padding: "8px 2px" }}>Žádné případy</div>'''

EMPTY_COL_NEW = '''                    <div
                      style={{
                        border: "1px dashed var(--paper-200)",
                        borderRadius: 10,
                        padding: "24px 12px",
                        textAlign: "center",
                        fontSize: 12,
                        color: "var(--ink-400)",
                      }}
                    >
                      Žádné případy
                    </div>'''

DETAIL_IMPORT_OLD = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS, getBadgeTextColor } from "@/lib/constants";'
DETAIL_IMPORT_NEW = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS, getBadgeTextColor, hexToRgba } from "@/lib/constants";'

GUIDANCE_OLD = '''            background: deal.status === "Ztraceno" ? "var(--paper-100)" : "#fdf3ec",
            border: `1px solid ${deal.status === "Ztraceno" ? "var(--paper-200)" : "var(--ember-500)"}`,'''

GUIDANCE_NEW = '''            background: deal.status === "Ztraceno" ? "var(--paper-100)" : hexToRgba(STATUS_COLORS[deal.status], 0.14),
            border: `1px solid ${deal.status === "Ztraceno" ? "var(--paper-200)" : STATUS_COLORS[deal.status]}`,'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(LIST_PATH)
    backup(DETAIL_PATH)

    apply_patch(LIST_PATH, EMPTY_COL_OLD, EMPTY_COL_NEW, "prazdny sloupec placeholder")
    apply_patch(DETAIL_PATH, DETAIL_IMPORT_OLD, DETAIL_IMPORT_NEW, "import hexToRgba v detailu dealu")
    apply_patch(DETAIL_PATH, GUIDANCE_OLD, GUIDANCE_NEW, "barva karty Co dal podle stavu")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "dashed var(--paper-200)" "{LIST_PATH}"')
    print(f'  grep -n "hexToRgba" "{DETAIL_PATH}"')
