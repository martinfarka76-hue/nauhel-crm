#!/usr/bin/env python3
"""
1) Presune hexToRgba() z page.js do sdileneho constants.js (exportovana),
   at ji muze pouzivat i detail dealu.
2) page.js: odstrani lokalni definici hexToRgba, importuje ji z constants.
3) deals/[id]/page.js: prida hexToRgba do importu, a karta "Co dal"
   dostane pozadi/ramecek podle STATUS_COLORS[deal.status] (svetly
   14% nadech barvy + plna barva jako border) - text zustava beze
   zmeny (uz je dost tmavy, zadne riziko kontrastu).

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha vsech
puvodnich souboru vedle nich (.bak).
"""
import sys

CONSTANTS_PATH = "frontend-admin/lib/constants.js"
LIST_PATH = "frontend-admin/app/page.js"
DETAIL_PATH = "frontend-admin/app/deals/[id]/page.js"

# --- 1) pridat hexToRgba do constants.js (na konec souboru, za getBadgeTextColor) ---
CONSTANTS_OLD = '''  const contrastWithWhite = 1.05 / (luminance + 0.05);
  return contrastWithWhite >= 4.5 ? "#fff" : "var(--ink-900)";
}'''

CONSTANTS_NEW = '''  const contrastWithWhite = 1.05 / (luminance + 0.05);
  return contrastWithWhite >= 4.5 ? "#fff" : "var(--ink-900)";
}

export function hexToRgba(hex, alpha) {
  const h = hex.replace("#", "");
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}'''

# --- 2) page.js: odstranit lokalni definici, pouzit import ---
LIST_FUNC_OLD = '''function hexToRgba(hex, alpha) {
  const h = hex.replace("#", "");
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

'''
LIST_FUNC_NEW = ""

LIST_IMPORT_OLD = 'import { DEAL_STATUSES, STATUS_COLORS, getBadgeTextColor } from "@/lib/constants";'
LIST_IMPORT_NEW = 'import { DEAL_STATUSES, STATUS_COLORS, getBadgeTextColor, hexToRgba } from "@/lib/constants";'

# --- 3) detail dealu: import + karta "Co dal" ---
DETAIL_IMPORT_OLD = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS, getBadgeTextColor } from "@/lib/constants";'
DETAIL_IMPORT_NEW = 'import { STATUS_COLORS, NEXT_MANUAL_STATUS, getBadgeTextColor, hexToRgba } from "@/lib/constants";'

DETAIL_CARD_OLD = '''            background: deal.status === "Ztraceno" ? "var(--paper-100)" : "#fdf3ec",
            border: `1px solid ${deal.status === "Ztraceno" ? "var(--paper-200)" : "var(--ember-500)"}`,'''

DETAIL_CARD_NEW = '''            background: deal.status === "Ztraceno" ? "var(--paper-100)" : hexToRgba(STATUS_COLORS[deal.status], 0.14),
            border: `1px solid ${deal.status === "Ztraceno" ? "var(--paper-200)" : STATUS_COLORS[deal.status]}`,'''


def apply_patch(path, old, new, label, allow_zero=False):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0 and not allow_zero:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    if count == 1:
        content = content.replace(old, new)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    for p in (CONSTANTS_PATH, LIST_PATH, DETAIL_PATH):
        backup(p)

    apply_patch(CONSTANTS_PATH, CONSTANTS_OLD, CONSTANTS_NEW, "pridani hexToRgba do constants.js")
    apply_patch(LIST_PATH, LIST_FUNC_OLD, LIST_FUNC_NEW, "odstraneni lokalni hexToRgba v page.js")
    apply_patch(LIST_PATH, LIST_IMPORT_OLD, LIST_IMPORT_NEW, "import hexToRgba v page.js")
    apply_patch(DETAIL_PATH, DETAIL_IMPORT_OLD, DETAIL_IMPORT_NEW, "import hexToRgba v detailu dealu")
    apply_patch(DETAIL_PATH, DETAIL_CARD_OLD, DETAIL_CARD_NEW, "barva karty Co dal podle stavu")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "hexToRgba" "{CONSTANTS_PATH}" "{LIST_PATH}" "{DETAIL_PATH}"')
