#!/usr/bin/env python3
"""
Kontrast bileho textu na --ember-500 (#b5652d) je 4.32:1, tesne pod WCAG
pragem 4.5:1 - tyka se .btn-primary (klidovy stav, hover uz je OK na
ember-600) a .deal-card-avatar (kolecko s inicialou firmy na Kanban
kartach, male tucne pismo - jeste prisnejsi pozadavek na kontrast).

Reseni: nova promenna --ember-btn: #b1622c (jen 2% tmavsi, opticky
nerozeznatelne, kontrast 4.51:1) - pouzita JEN na tehle 2 mistech.
--ember-500 zustava beze zmeny vsude jinde (logo, aktivni polozka menu,
focus outline) - to jsou brandove/dekorativni pouziti, ne bezny UI text.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

CSS_PATH = "frontend-admin/app/globals.css"

ROOT_OLD = '''  --ember-500: #b5652d;
  --ember-600: #9c5424;'''

ROOT_NEW = '''  --ember-500: #b5652d;
  --ember-600: #9c5424;
  --ember-btn: #b1622c;'''

BTN_OLD = '''.btn-primary {
  background: var(--ember-500);
  color: #fff;
}'''

BTN_NEW = '''.btn-primary {
  background: var(--ember-btn);
  color: #fff;
}'''

AVATAR_OLD = '''.deal-card-avatar {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: var(--ember-500);
  color: #fff;
  font-size: 10.5px;
  font-weight: 700;'''

AVATAR_NEW = '''.deal-card-avatar {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: var(--ember-btn);
  color: #fff;
  font-size: 10.5px;
  font-weight: 700;'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(CSS_PATH)
    apply_patch(CSS_PATH, ROOT_OLD, ROOT_NEW, "pridani --ember-btn promenne")
    apply_patch(CSS_PATH, BTN_OLD, BTN_NEW, "btn-primary pozadi")
    apply_patch(CSS_PATH, AVATAR_OLD, AVATAR_NEW, "deal-card-avatar pozadi")

    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "ember-btn" "{CSS_PATH}"')
