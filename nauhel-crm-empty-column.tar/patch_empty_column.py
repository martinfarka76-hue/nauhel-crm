#!/usr/bin/env python3
"""
Prazdny sloupec na Kanbanu ("Zadne pripady") dostane misto proste sedeho
textu box s preruovanym rameckem - vizualne naznacuje "sem patri karta",
ne chybejici obsah. Cistokosmeticka uprava, zadna nova logika.

Bezpecne: overuje presny pocet vyskytu PRED zapisem, zaloha puvodniho
souboru vedle nej (.bak).
"""
import sys

JS_PATH = "frontend-admin/app/page.js"

OLD = '''                    <div style={{ fontSize: 12, color: "var(--ink-400)", padding: "8px 2px" }}>Žádné případy</div>'''

NEW = '''                    <div
                      style={{
                        border: "1px dashed var(--paper-200)",
                        borderRadius: 10,
                        padding: "24px 12px",
                        textAlign: "center",
                        fontSize: 12,
                        color: "var(--ink-400)",
                      }}
                    >
                      Žádné případy
                    </div>'''


def apply_patch(path, old, new, label):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    count = content.count(old)
    if count == 0:
        print(f"CHYBA: usek '{label}' nebyl v souboru {path} nalezen. Nic jsem nezmenil.")
        sys.exit(1)
    if count > 1:
        print(f"CHYBA: usek '{label}' se v souboru {path} vyskytuje {count}x (ocekavana 1x). Nic jsem nezmenil.")
        sys.exit(1)
    content = content.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: usek '{label}' upraven v {path}.")


def backup(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.read()
    with open(path + ".bak", "w", encoding="utf-8") as f:
        f.write(data)
    print(f"Zaloha vytvorena: {path}.bak")


if __name__ == "__main__":
    backup(JS_PATH)
    apply_patch(JS_PATH, OLD, NEW, "prazdny sloupec placeholder")
    print("\nHotovo. Zkontroluj vystup:")
    print(f'  grep -n "dashed var(--paper-200)" "{JS_PATH}"')
